$(document).ready(function(){
    $('.burger').click(function(){
        $('.burger').toggleClass('active');
        $('#navigation').toggleClass('activeNav');
    })
})